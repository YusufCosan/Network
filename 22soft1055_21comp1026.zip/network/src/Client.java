// === File: Client.java ===

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    private static final int LB_PORT = 6000;
    private static final String LB_HOST = "localhost";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter command (list / compute <sec> / stream <sec> / download <filename>): ");
        String command = scanner.nextLine().trim();
        String[] parts = command.split(" ");
        if (parts.length == 0) {
            System.out.println("❌ Invalid input.");
            return;
        }

        String action = parts[0].toLowerCase();
        InetSocketAddress serverAddress = requestServerFromLoadBalancer();
        if (serverAddress == null) {
            System.out.println("⚠️ No available servers.");
            return;
        }

        try (Socket serverSocket = new Socket(serverAddress.getHostName(), serverAddress.getPort());
             BufferedReader in = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(serverSocket.getOutputStream()))) {

            out.write(command + "\n");
            out.flush();

            switch (action) {
                case "list":
                case "compute":
                case "stream": {
                    String line;
                    while ((line = in.readLine()) != null) {
                        System.out.println(line);
                    }
                    break;
                }
                case "download": {
                    if (parts.length < 2) {
                        System.out.println("❌ Usage: download <filename>");
                        return;
                    }
                    String filename = parts[1];
                    String sizeLine = in.readLine();
                    if (sizeLine != null && sizeLine.startsWith("SIZE")) {
                        int size = Integer.parseInt(sizeLine.split(" ")[1]);
                        byte[] fileData = new byte[size];
                        InputStream is = serverSocket.getInputStream();
                        int totalRead = 0;
                        while (totalRead < size) {
                            int bytesRead = is.read(fileData, totalRead, size - totalRead);
                            if (bytesRead == -1) break;
                            totalRead += bytesRead;
                        }
                        File dir = new File("client_downloads");
                        if (!dir.exists()) dir.mkdir();
                        File file = new File(dir, filename);
                        try (FileOutputStream fos = new FileOutputStream(file)) {
                            fos.write(fileData);
                        }
                        System.out.println("✅ Download complete: " + file.getAbsolutePath());
                    } else {
                        System.out.println("❌ Download failed or file not found.");
                    }
                    break;
                }
                default:
                    System.out.println("⚠️ Unknown command.");
            }

        } catch (IOException e) {
            System.out.println("❗ Client error: " + e.getMessage());
        }
    }

    private static InetSocketAddress requestServerFromLoadBalancer() {
        try (Socket lbSocket = new Socket(LB_HOST, LB_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(lbSocket.getInputStream()))) {
            String connectLine = in.readLine();
            if (connectLine != null && connectLine.startsWith("CONNECT")) {
                String[] parts = connectLine.split(" ");
                return new InetSocketAddress(parts[1], Integer.parseInt(parts[2]));
            } else {
                System.out.println("❌ Invalid response from LoadBalancer.");
            }
        } catch (IOException e) {
            System.out.println("❗ Failed to contact LoadBalancer: " + e.getMessage());
        }
        return null;
    }
}
