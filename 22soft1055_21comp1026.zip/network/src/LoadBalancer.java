// === File: LoadBalancer.java ===

import java.io.*;
import java.net.*;
import java.util.*;

public class LoadBalancer {
    private static final int CLIENT_PORT = 6000;
    private static final int SERVER_REGISTRATION_PORT = 7100;
    private static final int TIMEOUT_MS = 300000;

    private static class ServerInfo {
        InetAddress address;
        int port;
        int activeConnections = 0;
        long lastSeen = System.currentTimeMillis();
    }

    private static final List<ServerInfo> servers = Collections.synchronizedList(new ArrayList<>());
    private static String strategy = "dynamic";
    private static int rrIndex = 0;

    public static void main(String[] args) {
        if (args.length > 0) strategy = args[0].toLowerCase();
        new Thread(LoadBalancer::listenForServerRegistration).start();
        new Thread(LoadBalancer::timeoutWatcher).start();
        listenForClients();
    }

    private static void listenForServerRegistration() {
        try (ServerSocket serverSocket = new ServerSocket(SERVER_REGISTRATION_PORT)) {
            System.out.println("[LB] Listening for server registrations on port " + SERVER_REGISTRATION_PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String msg = in.readLine();
                String[] parts = msg.split(" ");

                if (parts.length == 2 && parts[0].equals("join")) {
                    int port = Integer.parseInt(parts[1]);
                    synchronized (servers) {
                        boolean exists = servers.stream().anyMatch(s -> s.port == port);
                        if (!exists) {
                            ServerInfo server = new ServerInfo();
                            server.address = socket.getInetAddress();
                            server.port = port;
                            servers.add(server);
                            System.out.println("[LB] ✅ Server joined: " + server.address + ":" + server.port);
                        }
                    }
                } else if (parts[0].equals("done") && parts.length == 2) {
                    int donePort = Integer.parseInt(parts[1]);
                    synchronized (servers) {
                        for (ServerInfo s : servers) {
                            if (s.port == donePort) {
                                s.activeConnections = Math.max(0, s.activeConnections - 1);
                                System.out.println("[LB] ✅ Server " + s.port + " marked as available (done). ActiveConnections=" + s.activeConnections);
                                break;
                            }
                        }
                    }
                } else if (parts[0].equals("goodbye") && parts.length == 2) {
                    int port = Integer.parseInt(parts[1]);
                    synchronized (servers) {
                        servers.removeIf(s -> s.port == port);
                        System.out.println("[LB] ❌ Server removed: " + port);
                    }
                }
                socket.close();
            }
        } catch (IOException e) {
            System.out.println("[LB] ❌ Registration listener error: " + e.getMessage());
        }
    }

    private static void listenForClients() {
        try (ServerSocket clientSocket = new ServerSocket(CLIENT_PORT)) {
            System.out.println("[LB] 🚪 LoadBalancer running on port " + CLIENT_PORT + " (strategy: " + strategy + ")");
            while (true) {
                Socket socket = clientSocket.accept();
                System.out.println("[LB] 📨 New client request received.");
                ServerInfo selected = selectServer();
                if (selected == null) {
                    System.out.println("[LB] ❌ No available servers.");
                    socket.close();
                    continue;
                }

                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                out.println("CONNECT " + selected.address.getHostAddress() + " " + selected.port);
                out.flush();

                if (strategy.equals("dynamic")) {
                    selected.activeConnections++;
                    System.out.println("[LB] DYNAMIC: Incremented activeConnections of server " + selected.port + " → " + selected.activeConnections);
                } else {
                    System.out.println("[LB] STATIC: Selected server " + selected.port);
                }

                selected.lastSeen = System.currentTimeMillis();
                System.out.println("[LB] ➡️ Routed to server: " + selected.address + ":" + selected.port);
                socket.close();
            }
        } catch (IOException e) {
            System.out.println("[LB] ❌ LoadBalancer error: " + e.getMessage());
        }
    }

    private static ServerInfo selectServer() {
        synchronized (servers) {
            servers.removeIf(s -> (System.currentTimeMillis() - s.lastSeen) > TIMEOUT_MS);
            if (servers.isEmpty()) return null;

            if (strategy.equals("static")) {
                rrIndex %= servers.size();
                return servers.get(rrIndex++);
            } else {
                return servers.stream().min(Comparator.comparingInt(s -> s.activeConnections)).orElse(null);
            }
        }
    }

    private static void timeoutWatcher() {
        while (true) {
            try {
                Thread.sleep(5000);
                synchronized (servers) {
                    long now = System.currentTimeMillis();
                    servers.removeIf(server -> {
                        boolean expired = now - server.lastSeen > TIMEOUT_MS;
                        if (expired) {
                            System.out.println("[LB] ⏱️ Server " + server.port + " timed out and removed.");
                        }
                        return expired;
                    });
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}