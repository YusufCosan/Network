// === File: Server.java ===

import java.io.*;
import java.net.*;

public class Server {
    private static int SERVER_PORT = 5050;
    private static final String LOAD_BALANCER_HOST = "localhost";
    private static final int LOAD_BALANCER_PORT = 7100;
    private static final String FILE_DIR = "server_files";
    private static volatile boolean isBusy = false;

    public static void main(String[] args) {
        if (args.length > 0) {
            try {
                SERVER_PORT = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.out.println("Invalid port number provided. Using default port 5050.");
            }
        }

        try {
            Socket lbSocket = new Socket(LOAD_BALANCER_HOST, LOAD_BALANCER_PORT);
            PrintWriter lbOut = new PrintWriter(lbSocket.getOutputStream(), true);
            lbOut.println("join " + SERVER_PORT);
            lbSocket.close();
            System.out.println("[SERVER " + SERVER_PORT + "] ✅ Registered to LoadBalancer.");

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                notifyGoodbye();
                System.out.println("[SERVER " + SERVER_PORT + "] 👋 Server shutting down gracefully...");
            }));

            File folder = new File(FILE_DIR);
            if (!folder.exists()) folder.mkdir();

            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            System.out.println("[SERVER " + SERVER_PORT + "] 🟢 Server running on port " + SERVER_PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleClient(clientSocket)).start();
            }

        } catch (IOException e) {
            System.out.println("[SERVER " + SERVER_PORT + "] ❌ Server error: " + e.getMessage());
        }
    }

    private static void handleClient(Socket clientSocket) {
        if (isBusy) {
            try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))) {
                out.write("BUSY\n");
                out.flush();
            } catch (IOException ignored) {}
            System.out.println("[SERVER " + SERVER_PORT + "] ❗ Rejected client: Server is busy.");
            try {
                clientSocket.close();
            } catch (IOException ignored) {}
            return;
        }
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))
        ) {
            String command = in.readLine();
            if (command == null || command.isEmpty()) return;

            String[] parts = command.trim().split(" ");
            String action = parts[0];

            System.out.println("[SERVER " + SERVER_PORT + "] 📥 Command received: " + command);

            switch (action) {
                case "list": {
                    File folder = new File(FILE_DIR);
                    String[] files = folder.list();
                    if (files != null && files.length > 0) {
                        for (String file : files) out.write(file + "\n");
                    } else {
                        out.write("No files available.\n");
                    }
                    out.flush();
                    System.out.println("[SERVER " + SERVER_PORT + "] 📂 Sent file list to client.");
                    notifyDone();
                    break;
                }

                case "compute": {
                    if (parts.length < 2) {
                        out.write("ERROR: Missing duration\n");
                        out.flush();
                        return;
                    }
                    isBusy = true;
                    int sec = Integer.parseInt(parts[1]);
                    System.out.println("[SERVER " + SERVER_PORT + "] 🧮 Starting computation for " + sec + " seconds...");
                    Thread.sleep(sec * 1000L);
                    out.write("Computation finished after " + sec + " seconds.\n");
                    out.flush();
                    System.out.println("[SERVER " + SERVER_PORT + "] ✅ Computation finished.");
                    notifyDone();
                    break;
                }

                case "download": {
                    if (parts.length < 2) {
                        out.write("ERROR: Missing filename\n");
                        out.flush();
                        return;
                    }
                    String filename = parts[1];
                    File file = new File(FILE_DIR + "/" + filename);
                    if (!file.exists()) {
                        out.write("ERROR: File not found\n");
                        out.flush();
                        System.out.println("[SERVER " + SERVER_PORT + "] ❌ File not found: " + filename);
                    } else {
                        isBusy = true;
                        out.write("SIZE " + file.length() + "\n");
                        out.flush();
                        try (FileInputStream fis = new FileInputStream(file);
                             OutputStream os = clientSocket.getOutputStream()) {
                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = fis.read(buffer)) != -1) {
                                os.write(buffer, 0, bytesRead);
                            }
                            os.flush();
                        }
                        System.out.println("[SERVER " + SERVER_PORT + "] ✅ File sent: " + filename);
                        notifyDone();
                    }
                    break;
                }

                case "stream": {
                    if (parts.length < 2) {
                        out.write("ERROR: Missing duration\n");
                        out.flush();
                        return;
                    }
                    isBusy = true;
                    int streamSec = Integer.parseInt(parts[1]);
                    for (int i = 1; i <= streamSec; i++) {
                        out.write("FRAME " + i + "\n");
                        out.flush();
                        Thread.sleep(1000);
                    }
                    System.out.println("[SERVER " + SERVER_PORT + "] 📺 Streamed " + streamSec + " frames.");
                    notifyDone();
                    break;
                }

                default:
                    out.write("ERROR: Unknown command\n");
                    out.flush();
                    System.out.println("[SERVER " + SERVER_PORT + "] ⚠️ Unknown command received.");
            }

        } catch (Exception e) {
            System.out.println("[SERVER " + SERVER_PORT + "] ❗ Error handling client: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.out.println("[SERVER " + SERVER_PORT + "] ❗ Error closing client socket: " + e.getMessage());
            }
        }
    }

    private static void notifyDone() {
        try (Socket doneSocket = new Socket(LOAD_BALANCER_HOST, LOAD_BALANCER_PORT);
             PrintWriter out = new PrintWriter(doneSocket.getOutputStream(), true)) {
            out.println("done " + SERVER_PORT);
            System.out.println("[SERVER " + SERVER_PORT + "] ✅ Sent DONE to LoadBalancer.");
        } catch (IOException e) {
            System.out.println("[SERVER " + SERVER_PORT + "] ❗ Error sending done message: " + e.getMessage());
        }
        isBusy = false;
    }

    private static void notifyGoodbye() {
        try (Socket goodbyeSocket = new Socket(LOAD_BALANCER_HOST, LOAD_BALANCER_PORT);
             PrintWriter out = new PrintWriter(goodbyeSocket.getOutputStream(), true)) {
            out.println("goodbye " + SERVER_PORT);
        } catch (IOException e) {
            System.out.println("[SERVER " + SERVER_PORT + "] ❗ Error sending goodbye message: " + e.getMessage());
        }
    }
}